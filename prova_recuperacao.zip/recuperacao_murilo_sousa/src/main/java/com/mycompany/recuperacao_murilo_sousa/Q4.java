/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.recuperacao_murilo_sousa;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author m.sousa
 */
public class Q4 {
    public static void main(String[] args) throws IOException {
        DataInputStream dado = new DataInputStream (System.in);
        String s;
        int cod,codigo=1234,senha,senhaCo=9999;
        do{
        System.out.println("Digite seu codigo de usuario: ");
        s = dado.readLine();
        cod = Integer.parseInt(s);

        if(cod != codigo){
            System.out.println("Usuario invalido!");
        }
        }while(cod != codigo);
        
        do{
        System.out.println("Digite senha de usuario: ");
        s = dado.readLine();
        senha = Integer.parseInt(s);
        
        if(senha == senhaCo){
            System.out.println("Acesso permitido!");
        }else if(senha != senhaCo){
                System.out.println("Senha incorreta");
        }
        }while(senha != senhaCo);
       
        
    }
}
