/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.recuperacao_murilo_sousa;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author m.sousa
 */
public class Q18 {
    public static void main(String[] args) throws IOException {
        DataInputStream dado = new DataInputStream(System.in);
        String s;
        float ganhoH,salarioM,inss,sindicato,impostoR,teste,salarioL,totalUm,totaldois;
        int horas;
        
        System.out.println("Quantos você ganha por hora? ");
        s = dado.readLine();
        ganhoH = Float.parseFloat(s);
        
        System.out.println("Quantas horas trabalha por mês? ");
        s = dado.readLine();
        horas = Integer.parseInt(s);
        
        salarioM = ganhoH * horas;
        inss = (float) (salarioM * 0.11);
        
        totalUm = salarioM - inss;
        sindicato = (float) (totalUm - (totalUm*0.05));
        
        totaldois = totalUm - sindicato;
        impostoR = (float) (totaldois - (totaldois*0.08));
        
        salarioL = salarioM - inss - impostoR;
        
        System.out.println("Salario bruto "+salarioM);
        System.out.println("Pagou "+ inss +" Reais de INSS."); 
        System.out.println("Pagou "+sindicato+" Reais de sindicato.");
        System.out.println("Pagou "+impostoR+" Reais de imposto de renda.");
        System.out.println("Salario liquido é de: "+salarioL+" Reais");
    }
}
