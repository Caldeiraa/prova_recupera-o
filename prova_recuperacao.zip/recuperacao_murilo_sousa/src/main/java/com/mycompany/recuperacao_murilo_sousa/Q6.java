/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.recuperacao_murilo_sousa;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author m.sousa
 */
public class Q6 {
    public static void main(String[] args) throws IOException {
        DataInputStream dado = new DataInputStream(System.in);
        String nome,nomeFilCo,nomeFi;
        String [] pista = new String [5];
        System.out.println("Jogador 1 - digite seu nome:");
        nome = dado.readLine();
        System.out.println(nome+" digite o nome do filme: ");
        nomeFilCo= dado.readLine();
        
        for(int i=0;i<5;i++){
           System.out.println(nome+" digite a pista "+(i+1)+": "); 
           pista[i] = dado.readLine();
        }
        
        System.out.println("Jogador 2- digite seu nome:");
        nome = dado.readLine();
        
        for(int i=0;i<5;i++){
            System.out.println(nome+" a pista "+(i+1)+" é: "+pista[i]);
            
             System.out.println("Qual o nome do filme? ");
             nomeFi = dado.readLine();
             if(nomeFi.equals(nomeFilCo)){
                 System.out.println("Acertou ");
                 break;
             }else if(nomeFi == null ? nomeFilCo != null : !nomeFi.equals(nomeFilCo)){
               System.out.println(nome+" Você errou!");  
             }
        }
    }
}
