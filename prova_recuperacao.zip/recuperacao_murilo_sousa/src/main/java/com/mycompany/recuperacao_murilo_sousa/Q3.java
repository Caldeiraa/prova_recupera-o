/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.recuperacao_murilo_sousa;

import java.io.DataInputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author m.sousa
 */
public class Q3 {
    public static void main(String[] args) {
        String s;
        int n1,anter,suce;
        
        s = JOptionPane.showInputDialog(null, "Digite um numero inteiro");
        n1 = Integer.parseInt(s);
        
        anter = n1 - 1;
        suce = n1 + 1;
        
        JOptionPane.showMessageDialog(null, "O antecessor de "+n1+" é "+anter+" e o sucessor é "+suce);
                
    }
    
}
