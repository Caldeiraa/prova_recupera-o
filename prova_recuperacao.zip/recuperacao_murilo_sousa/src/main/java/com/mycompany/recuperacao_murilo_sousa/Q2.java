/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.recuperacao_murilo_sousa;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author m.sousa
 */
public class Q2 {
    public static void main(String[] args) throws IOException {
        DataInputStream dado = new DataInputStream (System.in);
        String s;
        int cafe,expreco=0,capuccino=0,cafeL=0,contadorT=0;
        float total=0,cafeCa=0,cafeEx = 0,cafeCL=0;
        do{
        System.out.println("1- Café expresso");
        System.out.println("2- Café capuccino");
        System.out.println("3- Leite com café");
        System.out.println("4- Totalizar vendas");
        s = dado.readLine();
        cafe = Integer.parseInt(s);
        
        if(cafe == 1){
            cafeEx = (float) (cafeEx + 0.75);
            total = (float) (total + 0.75);
            expreco++;
           contadorT++;
           
           }else if(cafe == 2){
                cafeCa = (float) (cafeCa + 1);
                 total = (float) (total + 1);
                capuccino++;
                 contadorT++;
                 
           }else if(cafe == 3){
                cafeCL = (float) (cafeCL + 1.25);
                total = (float) (total + 1.25);
                cafeL++;
                 contadorT++;
                 
           }else if(cafe == 4){
                System.out.println("Quantidade de cafe expresso foi: "+expreco+" e o valor: "+cafeEx);
                System.out.println("Quantidade de cafe expresso foi: "+capuccino+" e o valor: "+cafeCa);
                System.out.println("Quantidade de cafe expresso foi: "+cafeL+" e o valor: "+cafeCL);
                System.out.println("Quantidade total foi de : "+contadorT+" e o valor: "+total);
                
           }else{
              System.out.println("somente de 1 a 4"); 
           }
           }while(cafe != 4);     
           
    }
}
